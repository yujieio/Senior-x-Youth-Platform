# Database Structure Documentation
## InterGen Connect - IT1125 Web Development Project

## Database Technology
- **Database Type**: SQLite
- **ORM Framework**: Flask-SQLAlchemy
- **Database File**: `project.db`

## Tables Summary

### Total Tables: 5

1. **skill_post** - Skill exchange posts
2. **user_profile** - User profile information
3. **bingo_prompt** - Bingo game prompts
4. **bingo_story** - User stories for bingo prompts
5. **bingo_comment** - Comments on bingo stories

---

## Table: `skill_post`

**Purpose**: Stores skill exchange posts created by users offering or requesting skills.

**Python Model Class**: `SkillPost`

### Schema

| Column Name | Data Type | Constraints | Description |
|------------|-----------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, NOT NULL | Unique identifier |
| `title` | VARCHAR(100) | NOT NULL | Post title (max 100 chars) |
| `description` | TEXT | NOT NULL | Post description |
| `category` | VARCHAR(50) | NOT NULL | Skill category |
| `skill_type` | VARCHAR(20) | NOT NULL | 'Offer' or 'Request' |
| `user_type` | VARCHAR(20) | NOT NULL | 'Youth' or 'Senior' |
| `date_posted` | DATETIME | NULLABLE | Creation timestamp |

### CRUD Operations
- **CREATE**: `/skills/new` (POST) - `create_skill()`
- **READ**: `/skills` (GET) - `skills_exchange()`, `/skills/<id>` (GET) - `skill_detail()`
- **UPDATE**: `/skills/<id>/edit` (GET, POST) - `edit_skill()`
- **DELETE**: `/skills/<id>/delete` (POST) - `delete_skill()`

---

## Table: `user_profile`

**Purpose**: Stores user profile information including preferences and accessibility settings.

**Python Model Class**: `UserProfile`

### Schema

| Column Name | Data Type | Constraints | Description |
|------------|-----------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, NOT NULL | Unique identifier |
| `name` | VARCHAR(100) | NOT NULL | User's full name |
| `user_type` | VARCHAR(20) | NOT NULL | 'Youth' or 'Senior' |
| `languages` | VARCHAR(200) | NULLABLE | Comma-separated languages |
| `short_intro` | TEXT | NULLABLE | User bio/introduction |
| `interaction_type` | VARCHAR(20) | DEFAULT '1-to-1' | '1-to-1' or 'Group' |
| `meeting_style` | VARCHAR(20) | DEFAULT 'Online' | 'Online' or 'In-Person' |
| `interest_tags` | VARCHAR(500) | NULLABLE | Comma-separated interest tags |
| `large_text` | BOOLEAN | DEFAULT FALSE | Accessibility: large text mode |
| `high_contrast` | BOOLEAN | DEFAULT FALSE | Accessibility: high contrast mode |
| `easy_reading` | BOOLEAN | DEFAULT FALSE | Accessibility: easy reading mode |
| `is_active` | BOOLEAN | DEFAULT TRUE | Soft delete flag |
| `date_created` | DATETIME | NULLABLE | Creation timestamp |
| `date_updated` | DATETIME | NULLABLE | Last update timestamp |

### CRUD Operations
- **CREATE**: `/profile/create` (GET, POST) - `profile_create()`
- **READ**: `/profile` (GET) - `profile()`
- **UPDATE**: `/profile/edit` (GET, POST) - `profile_edit()`
- **DELETE**: `/profile/delete` (POST) - `profile_delete()` (soft delete)

---

## Table: `bingo_prompt`

**Purpose**: Stores prompts for the bingo storytelling game.

**Python Model Class**: `BingoPrompt`

### Schema

| Column Name | Data Type | Constraints | Description |
|------------|-----------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, NOT NULL | Unique identifier |
| `prompt_text` | VARCHAR(200) | NOT NULL | Prompt text |
| `position` | INTEGER | NOT NULL | Position on board (1-25 for 5x5 grid) |
| `category` | VARCHAR(50) | NULLABLE | Optional category |
| `is_active` | BOOLEAN | DEFAULT TRUE | Active status |
| `date_created` | DATETIME | NULLABLE | Creation timestamp |

---

## Table: `bingo_story`

**Purpose**: Stores user stories submitted for bingo prompts.

**Python Model Class**: `BingoStory`

### Schema

| Column Name | Data Type | Constraints | Description |
|------------|-----------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, NOT NULL | Unique identifier |
| `prompt_id` | INTEGER | NOT NULL, FOREIGN KEY | References bingo_prompt(id) |
| `author_name` | VARCHAR(100) | NOT NULL | Author's name |
| `user_type` | VARCHAR(20) | NOT NULL | 'Youth' or 'Senior' |
| `title` | VARCHAR(200) | NOT NULL | Story title |
| `story_content` | TEXT | NOT NULL | Story content |
| `photo_url` | VARCHAR(500) | NULLABLE | Optional photo URL |
| `points_earned` | INTEGER | DEFAULT 10 | Points for posting |
| `likes_count` | INTEGER | DEFAULT 0 | Number of likes |
| `comments_count` | INTEGER | DEFAULT 0 | Number of comments |
| `is_published` | BOOLEAN | DEFAULT TRUE | Publication status |
| `date_posted` | DATETIME | NULLABLE | Creation timestamp |
| `date_updated` | DATETIME | NULLABLE | Last update timestamp |

### CRUD Operations
- **CREATE**: `/bingo/create` (GET, POST) - `bingo_create_story()`
- **READ**: `/bingo/stories` (GET) - `bingo_stories()`, `/bingo/story/<id>` (GET) - `bingo_story_detail()`
- **UPDATE**: `/bingo/story/<id>/edit` (GET, POST) - `bingo_edit_story()`
- **DELETE**: `/bingo/story/<id>/delete` (POST) - `bingo_delete_story()`

---

## Table: `bingo_comment`

**Purpose**: Stores comments on bingo stories.

**Python Model Class**: `BingoComment`

### Schema

| Column Name | Data Type | Constraints | Description |
|------------|-----------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, NOT NULL | Unique identifier |
| `story_id` | INTEGER | NOT NULL, FOREIGN KEY | References bingo_story(id) |
| `author_name` | VARCHAR(100) | NOT NULL | Commenter's name |
| `comment_text` | TEXT | NOT NULL | Comment content |
| `points_earned` | INTEGER | DEFAULT 2 | Points for commenting |
| `date_posted` | DATETIME | NULLABLE | Creation timestamp |

### CRUD Operations
- **CREATE**: `/bingo/story/<id>/comment` (POST) - `bingo_add_comment()`

---

## Relationships

- `bingo_story.prompt_id` → `bingo_prompt.id`
- `bingo_comment.story_id` → `bingo_story.id`

---

## Database File Location
`c:\Users\User\Downloads\yujie webdev\project.db`
