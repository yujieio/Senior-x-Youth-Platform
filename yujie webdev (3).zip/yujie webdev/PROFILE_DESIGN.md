# Bridge Profile Page - Design Specification
## Premium, Modern, Theme-Consistent Design

---

## 1. THEME CONSISTENCY

### Color Palette (Matching Existing Theme)
- **Primary Dark**: `#1a222d` (navbar, buttons, text)
- **Light Backgrounds**: `#ffffff`, `#f8f9fa`, `#f5f6f8` (sections)
- **Accent Yellow**: `#ffc107` / Bootstrap `warning` (highlights, stats)
- **Accent Blue**: `#0d6efd` / Bootstrap `primary` (CTAs, links)
- **Text Colors**: 
  - Dark: `#1a222d` (on light backgrounds)
  - Light: `#f0f0f0`, `#bdc3c7` (on dark backgrounds)
- **Safe Tints/Shades**:
  - `rgba(26, 34, 45, 0.1)` - subtle backgrounds
  - `rgba(26, 34, 45, 0.05)` - borders
  - `#2c3e50` - darker shade for gradients

### Typography
- **Headings**: `Oswald` (500, 700), uppercase, letter-spacing: 1px
- **Body**: `Roboto` (300, 400, 500)
- **Font Sizes**:
  - H1: `display-3` / `display-4` (2.5rem - 3rem)
  - H2: `display-5` / `h2` (2rem)
  - H3: `h3` (1.75rem)
  - Body: `1rem` (base), `1.25rem` (lead)
  - Small: `0.875rem`

### Button Styles
- **Primary**: `btn-dark`, `btn-lg`, `rounded-pill`, `px-5 py-3`
- **Secondary**: `btn-outline-dark`, `btn-outline-light`
- **Icons**: Bootstrap Icons, `me-2` spacing
- **Hover**: `translateY(-2px)`, shadow increase

### Card Styles
- **Background**: `#ffffff`
- **Border Radius**: `16px` (cards), `24px` (large sections)
- **Shadow**: `0 10px 40px rgba(0, 0, 0, 0.1)`
- **Hover**: `translateY(-5px)`, `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15)`
- **Padding**: `p-4 p-lg-5`

### Spacing
- **Section Padding**: `py-5` (vertical), `px-4` (horizontal)
- **Card Gaps**: `g-4` (grid gaps)
- **Element Spacing**: `mb-4`, `mb-5` (margins)

---

## 2. PAGE STRUCTURE

### Layout (Desktop)
```
┌─────────────────────────────────────────────────┐
│ Header Section (Hero-style)                     │
│ - Profile Photo + Name + Tag                    │
│ - Quick Actions (Edit, Share)                   │
└─────────────────────────────────────────────────┘

┌──────────────────┬──────────────────────────────┐
│ Main Content     │ Sidebar                      │
│                  │                              │
│ 1. Key Info      │ CRUD Actions Card            │
│ 2. Preferences   │ (Create, Read, Update,       │
│ 3. Accessibility │  Delete)                     │
│ 4. Recent Activity│                              │
│ 5. Interest Tags │ Benefits Card                │
└──────────────────┴──────────────────────────────┘
```

### Layout (Mobile)
```
┌─────────────────────┐
│ Header              │
├─────────────────────┤
│ Key Info            │
├─────────────────────┤
│ Preferences         │
├─────────────────────┤
│ Accessibility       │
├─────────────────────┤
│ Recent Activity     │
├─────────────────────┤
│ Interest Tags       │
├─────────────────────┤
│ CRUD Actions        │
├─────────────────────┤
│ Benefits            │
└─────────────────────┘
```

---

## 3. COMPONENT LIST

### A. Header Card
- Large profile photo (circular, 120px)
- Name (Oswald, uppercase, large)
- Youth/Senior badge (colored chip)
- Languages (small chips)
- Short intro text
- Edit/Share buttons (top right)

### B. Key Profile Info Card
- Section title with icon
- Name, user type, languages
- Short bio/intro paragraph
- Clean, readable layout

### C. Preferred Interaction Style Card
- Section title
- Toggle buttons: 1-to-1 vs Group
- Toggle buttons: Online vs In-person
- Visual icons for each option

### D. Accessibility Options Card
- Section title
- Toggle switches:
  - Large Text (increases font sizes)
  - High Contrast (improves contrast)
  - Easy Reading (spacing adjustments)
- Live preview indicators

### E. Recent Participation Card
- Section title
- Activity list (skeleton loading state)
- Each activity: icon, title, date, link
- "View All" link

### F. Interest Tags Card
- Section title
- Tag chips (rounded, colored)
- Searchable/filterable (conceptually)
- Add/Remove tags (edit mode)

### G. CRUD Actions Card (Sidebar)
- Compact card with icons
- Create: "Set up profile" + icon
- Read: "View profile" + icon
- Update: "Edit details" + icon
- Delete: "Deactivate" + icon (warning color)

### H. Benefits Card (Sidebar)
- Small card explaining value
- 3 key benefits with icons
- Builds trust, conversation starters, accessibility

---

## 4. STYLE GUIDE

### Colors (Reusing Existing)
```css
/* Primary Colors */
--color-dark: #1a222d;
--color-light-bg: #ffffff;
--color-section-bg: #f8f9fa;
--color-accent-yellow: #ffc107;
--color-accent-blue: #0d6efd;

/* Tints/Shades */
--color-dark-10: rgba(26, 34, 45, 0.1);
--color-dark-05: rgba(26, 34, 45, 0.05);
--color-text-muted: #6c757d;
```

### Typography Hierarchy
```css
/* Headings */
.profile-h1 { font-family: 'Oswald'; font-size: 2.5rem; text-transform: uppercase; }
.profile-h2 { font-family: 'Oswald'; font-size: 2rem; text-transform: uppercase; }
.profile-h3 { font-family: 'Oswald'; font-size: 1.5rem; text-transform: uppercase; }

/* Body */
.profile-body { font-family: 'Roboto'; font-size: 1rem; line-height: 1.8; }
.profile-lead { font-family: 'Roboto'; font-size: 1.25rem; line-height: 1.8; }
```

### Spacing System
- **Section Padding**: `py-5` (3rem vertical)
- **Card Padding**: `p-4 p-lg-5` (1.5rem / 3rem)
- **Element Gaps**: `mb-4` (1.5rem), `mb-5` (3rem)
- **Grid Gaps**: `g-4` (1.5rem)

### Border Radius
- **Cards**: `16px` (`rounded-4`)
- **Large Sections**: `24px` (`rounded-5`)
- **Buttons**: `50px` (`rounded-pill`)
- **Chips/Tags**: `20px` (`rounded-pill`)

### Shadows
- **Cards**: `0 10px 40px rgba(0, 0, 0, 0.1)`
- **Hover**: `0 20px 40px rgba(0, 0, 0, 0.15)`
- **Buttons**: `0 4px 15px rgba(0, 0, 0, 0.1)`

### Micro-interactions
- **Hover**: `transform: translateY(-2px)`, `transition: all 0.3s ease`
- **Focus**: `outline: 2px solid #0d6efd`, `outline-offset: 2px`
- **Active**: Slight scale `scale(0.98)`
- **Smooth**: `transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)`

---

## 5. COPY

### Page Headlines
- **Main**: "YOUR BRIDGE PROFILE"
- **Subheadline**: "Build trust, start conversations, and connect meaningfully across generations"

### Section Labels
1. **Key Profile Info**: "ABOUT YOU"
2. **Preferred Interaction**: "HOW YOU CONNECT"
3. **Accessibility Options**: "MAKE IT COMFORTABLE"
4. **Recent Participation**: "YOUR ACTIVITY"
5. **Interest Tags**: "COMMON GROUND"

### CTA Button Text
- **Edit Profile**: "EDIT PROFILE"
- **Save Changes**: "SAVE CHANGES"
- **Deactivate**: "DEACTIVATE PROFILE"
- **View All Activity**: "VIEW ALL ACTIVITY"
- **Add Tag**: "ADD INTEREST"

### Benefits Text
- **Builds Trust**: "Complete profiles help members feel confident connecting"
- **Conversation Starters**: "Shared interests make it easier to begin meaningful chats"
- **Accessibility Support**: "Customize your experience for comfort and clarity"

---

## 6. ACCESSIBILITY FEATURES

### Large Text Mode
- Increases base font size: `1rem` → `1.25rem`
- Increases heading sizes proportionally
- Increases line-height: `1.8` → `2.2`
- Increases button padding

### High Contrast Mode
- Darker text: `#1a222d` → `#000000`
- Stronger borders: `1px` → `2px`
- Higher contrast ratios (WCAG AAA)
- Maintains theme colors but enhances contrast

### Easy Reading Mode
- Increased spacing between elements
- Wider line spacing
- Larger tap targets (min 44px)
- Reduced visual clutter

### Focus States
- Clear outline on interactive elements
- Keyboard navigation support
- Skip links for screen readers

### Reduce Motion
- Respects `prefers-reduced-motion`
- Subtle animations only
- No auto-playing content

---

## 7. PERFORMANCE CONSIDERATIONS

### Loading States
- Skeleton screens for "Recent Participation"
- Progressive image loading
- Lazy load activity items

### Efficient Rendering
- Tag chips rendered efficiently
- Searchable tag system (conceptually)
- Pagination for activity list (conceptually)

---

## 8. DESIGN IMPROVEMENTS EXPLANATION

### Trust Building
- **Complete Profile Display**: Shows all key information upfront, reducing uncertainty
- **Visual Consistency**: Matches site theme, feels professional and trustworthy
- **Clear User Type**: Prominent Youth/Senior badge helps set expectations
- **Activity History**: Recent participation shows engagement and authenticity

### Conversation Starters
- **Interest Tags**: Prominently displayed, easy to scan for common ground
- **Preferred Interaction Style**: Helps users know how to approach
- **Languages**: Shows communication options
- **Short Bio**: Personal touch that invites connection

### Accessibility Support
- **Toggle Controls**: Easy to find and use accessibility options
- **Live Preview**: Users see changes immediately
- **Large Text Option**: Makes content readable for seniors
- **High Contrast**: Improves visibility without breaking theme
- **Clear Labels**: All controls are clearly labeled and understandable

---

## 9. RESPONSIVE BREAKPOINTS

- **Mobile**: `< 768px` - Stacked layout, full-width cards
- **Tablet**: `768px - 992px` - 2-column grid
- **Desktop**: `> 992px` - Main content + sidebar layout

---

## 10. IMPLEMENTATION NOTES

- Use Bootstrap 5 grid system
- Maintain existing navbar (no changes)
- Use same card component pattern as Skills Exchange page
- Implement accessibility toggles with JavaScript
- Store preferences in localStorage (or backend)
- CRUD actions link to appropriate routes/forms

---

*Design matches existing theme: Warm + Modern + Clean + Professional*
