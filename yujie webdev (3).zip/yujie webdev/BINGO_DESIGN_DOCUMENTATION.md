# Bingo Storytelling Page - Design Documentation
## Premium Redesign Following Existing Theme

---

## 1. THEME CONSISTENCY

### Color Palette (Matching Existing Theme)
- **Primary Background**: `#f8f9fa` (light gray, warm)
- **Card Background**: `#ffffff` (white)
- **Dark Text**: `#1a222d` (dark blue-gray)
- **Success Green (Title)**: `#198754` (Bootstrap success)
- **Text Opacity**: `0.7-0.8` for secondary text
- **Accent Colors**:
  - Primary: `#0d6efd` (blue)
  - Success: `#198754` (green)
  - Warning: `#ffc107` (yellow)
  - Danger: `#dc3545` (red)
  - Info: `#0dcaf0` (cyan)

### Typography
- **Headings**: `'Oswald', sans-serif` - Uppercase, letter-spacing: 1px
- **Body**: `'Roboto', sans-serif` - Regular weight, line-height: 1.8
- **Font Sizes**:
  - Page Title: `display-3` (2.5rem)
  - Section Titles: `display-4` (2rem)
  - Step Titles: `1rem` (16px)
  - Body Text: `0.875rem` (14px) - `1rem` (16px)

### Spacing System
- **Section Padding**: `py-5` (3rem vertical)
- **Card Padding**: `p-4 p-lg-5` (1.5rem / 3rem)
- **Gap Between Elements**: `gap-3` (1rem) / `gap-4` (1.5rem)
- **Border Radius**: `16px` (cards), `12px` (badges), `50%` (icons)

### Shadows
- **Card Shadow**: `0 4px 12px rgba(0, 0, 0, 0.08)`
- **Hover Shadow**: `0 8px 20px rgba(0, 0, 0, 0.12)`
- **Button Shadow**: `0 4px 15px rgba(25, 135, 84, 0.3)`

---

## 2. PAGE STRUCTURE

### Desktop Layout
```
┌─────────────────────────────────────────┐
│         Hero Section (Centered)         │
│   - Green Title                         │
│   - Subheadline                        │
│   - CTA Button                          │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│      How It Works Flow (Horizontal)      │
│   [Step 1] → [Step 2] → [Step 3]       │
│   [Step 4] → [Step 5] → [Step 6]       │
└─────────────────────────────────────────┘
┌──────────────┬──────────────┐
│   Benefits   │    CRUD      │
│   (3 items)  │  (4 items)   │
└──────────────┴──────────────┘
┌─────────────────────────────────────────┐
│   Points & Rewards (3 Widget Cards)      │
└─────────────────────────────────────────┘
```

### Mobile Layout
```
┌─────────────────┐
│   Hero Section  │
└─────────────────┘
┌─────────────────┐
│  How It Works   │
│  (Vertical)     │
│  [Step 1]       │
│      ↓          │
│  [Step 2]       │
│      ↓          │
│  ...            │
└─────────────────┘
┌─────────────────┐
│   Benefits      │
└─────────────────┘
┌─────────────────┐
│   CRUD          │
└─────────────────┘
┌─────────────────┐
│   Rewards        │
│   (Stacked)      │
└─────────────────┘
```

---

## 3. COMPONENTS LIST

### 1. Hero Section
- **Title**: "BINGO STORYTELLING WITH POINTS" (green, uppercase)
- **Subheadline**: Descriptive text (max-width: 800px, centered)
- **CTA Button**: "GET STARTED" (success green, rounded-pill)

### 2. Bingo Flow Steps (6 Cards)
- **Step 1**: View Bingo Board (grid icon)
- **Step 2**: Choose Prompt (cursor icon) + "Optional Photo" badge
- **Step 3**: Write Story (pencil icon)
- **Step 4**: Publish (upload icon)
- **Step 5**: Engage (chat icon)
- **Step 6**: Earn Points (trophy icon)

### 3. Benefits Panel
- **Easy Starting Point** (lightbulb icon)
- **Ongoing Engagement** (refresh icon)
- **Low Pressure Experience** (heart icon)

### 4. CRUD Panel
- **Create** (plus icon) - Primary color
- **Retrieve** (eye icon) - Info color
- **Update** (pencil icon) - Success color
- **Delete** (trash icon) - Danger color

### 5. Rewards Widgets (3 Cards)
- **Earn Points** (star icon)
- **Unlock Badges** (award icon)
- **Redeem Rewards** (gift icon)

---

## 4. STYLE TOKENS

### Colors (Reusing Existing Palette)
```css
/* Backgrounds */
--bg-page: #f8f9fa;
--bg-card: #ffffff;
--bg-hover: #e9ecef;

/* Text */
--text-primary: #1a222d;
--text-secondary: rgba(26, 34, 45, 0.7);
--text-title-green: #198754;

/* Accents (Bootstrap Colors) */
--color-primary: #0d6efd;
--color-success: #198754;
--color-warning: #ffc107;
--color-danger: #dc3545;
--color-info: #0dcaf0;

/* Opacity Variants */
--success-bg-10: rgba(25, 135, 84, 0.1);
--primary-bg-10: rgba(13, 110, 253, 0.1);
--warning-bg-10: rgba(255, 193, 7, 0.1);
--danger-bg-10: rgba(220, 53, 69, 0.1);
```

### Typography Hierarchy
```css
/* Headings */
.bingo-title { font-size: 2.5rem; font-weight: 700; }
.section-title { font-size: 2rem; font-weight: 700; }
.step-title { font-size: 1rem; font-weight: 600; }

/* Body */
.lead { font-size: 1.25rem; line-height: 1.8; }
.body-text { font-size: 1rem; line-height: 1.8; }
.small-text { font-size: 0.875rem; line-height: 1.5; }
```

### Spacing
```css
--spacing-xs: 0.5rem;   /* 8px */
--spacing-sm: 1rem;     /* 16px */
--spacing-md: 1.5rem;   /* 24px */
--spacing-lg: 2rem;     /* 32px */
--spacing-xl: 3rem;     /* 48px */
```

### Border Radius
```css
--radius-sm: 12px;      /* Badges, small elements */
--radius-md: 16px;       /* Cards */
--radius-lg: 24px;       /* Large cards */
--radius-full: 50%;      /* Icons, avatars */
--radius-pill: 9999px;   /* Buttons */
```

### Shadows
```css
--shadow-sm: 0 4px 12px rgba(0, 0, 0, 0.08);
--shadow-md: 0 8px 20px rgba(0, 0, 0, 0.12);
--shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.15);
--shadow-button: 0 4px 15px rgba(25, 135, 84, 0.3);
```

---

## 5. MICRO-INTERACTIONS

### Hover States
```css
/* Cards */
.bingo-step-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-md);
}

/* Icons */
.bingo-step-icon:hover {
    transform: scale(1.1) rotate(5deg);
}

/* Buttons */
.bingo-cta-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(25, 135, 84, 0.4);
}

/* CRUD Items */
.bingo-crud-item:hover {
    background: var(--bg-hover);
    transform: translateX(5px);
}
```

### Focus States
```css
.bingo-cta-btn:focus {
    outline: 2px solid #198754;
    outline-offset: 2px;
}
```

### Active States
```css
.bingo-cta-btn:active {
    transform: translateY(0);
    box-shadow: var(--shadow-sm);
}
```

### Transitions
```css
/* All interactive elements */
transition: all 0.3s ease;

/* Icons */
transition: transform 0.3s ease;
```

---

## 6. COPYWRITING

### Hero Section
- **Headline**: "BINGO STORYTELLING WITH POINTS"
- **Subheadline**: "Turn storytelling into a fun, engaging game. Complete prompts, share your stories, earn points, and connect with our community through meaningful narratives."
- **CTA Button**: "GET STARTED"

### How It Works Steps
1. **View Bingo Board**: "Browse story prompts on the interactive bingo grid"
2. **Choose Prompt**: "Select a prompt that inspires your story"
3. **Write Story**: "Share your narrative based on the prompt"
4. **Publish**: "Post your story to the community blog"
5. **Engage**: "Read, comment, and share stories"
6. **Earn Points**: "Get rewarded for posting and engaging"

### Benefits
- **Easy Starting Point**: "Prompts help users start sharing without feeling stuck. No blank page anxiety—just pick a topic and begin."
- **Ongoing Engagement**: "Points and progress tracking encourage returning. Watch your bingo board fill up as you share more stories."
- **Low Pressure Experience**: "Guided format feels friendly for seniors and youths. Share at your own pace, no pressure to be perfect."

### CRUD Labels
- **Create**: "Post a story by choosing a bingo prompt and writing your narrative"
- **Retrieve**: "View bingo board, browse story blog, read details and comments"
- **Update**: "Edit your story or update post with more details"
- **Delete**: "Remove your story post (moderators can remove inappropriate posts)"

---

## 7. PERFORMANCE CONSIDERATIONS

### Loading States
- **Skeleton Screens**: For bingo grid and story cards
- **Lazy Loading**: Images load as user scrolls
- **Pagination**: Stories load in batches (e.g., 12 per page)

### Efficient Rendering
- **CSS Transitions**: Hardware-accelerated (transform, opacity)
- **Minimal Animations**: Subtle hover effects only
- **Optimized Images**: WebP format with fallbacks

### Mobile Optimization
- **Touch Targets**: Minimum 44px × 44px
- **Responsive Images**: srcset for different screen sizes
- **Stacked Layout**: Single column on mobile (< 768px)

---

## 8. ACCESSIBILITY

### Senior-Friendly Features
- **Large Text**: Minimum 16px body text
- **High Contrast**: Dark text (#1a222d) on light background (#ffffff)
- **Clear Buttons**: Large tap areas, rounded-pill shape
- **Simple Navigation**: Clear visual hierarchy

### WCAG Compliance
- **Color Contrast**: 4.5:1 minimum for text
- **Focus Indicators**: Visible outline on interactive elements
- **Semantic HTML**: Proper heading hierarchy, ARIA labels
- **Keyboard Navigation**: All interactive elements accessible via keyboard

---

## 9. RESPONSIVE BREAKPOINTS

```css
/* Mobile First Approach */
@media (max-width: 768px) {
    /* Stack layout vertically */
    /* Reduce font sizes */
    /* Full-width cards */
}

@media (max-width: 992px) {
    /* Two-column layout for benefits/CRUD */
    /* Horizontal flow becomes vertical */
}

@media (min-width: 993px) {
    /* Full desktop layout */
    /* Horizontal flow */
    /* Side-by-side benefits/CRUD */
}
```

---

## 10. IMPLEMENTATION CHECKLIST

- [x] HTML structure with semantic elements
- [x] CSS styles matching existing theme
- [x] Green title styling (#198754)
- [x] 6-step flow with icons and arrows
- [x] Benefits panel (3 items)
- [x] CRUD panel (4 items)
- [x] Rewards widgets (3 cards)
- [x] Responsive design (mobile/tablet/desktop)
- [x] Hover states and micro-interactions
- [x] Accessibility considerations
- [x] Performance optimizations

---

**Status**: ✅ Complete Design Documentation
**Last Updated**: January 26, 2026
**Theme Consistency**: ✅ Matches existing site perfectly
